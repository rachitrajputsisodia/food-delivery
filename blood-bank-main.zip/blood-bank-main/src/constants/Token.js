export const requestConfig = {
    headers: {
        Accept: 'application/json',
        Authorization:
            'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNzQ2NDM2MjA0LCJleHAiOjE3NDkwMjgyMDR9.KO3NWQFtBKNMhxBgg4hglnGO_Af79SIi6NkMkT1pafo',
    },
    timeout: 10000,
};