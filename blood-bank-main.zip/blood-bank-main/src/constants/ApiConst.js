export const API_BASE_URL = 'https://bloodbank.veldev.com/api/';

//Register
export const REGISTER = 'register';

//Login
export const LOGIN = 'auth/local';

//Cities
export const CITIES = 'cities';

//Blood Bank
export const BLOOD_BANK = 'blood-banks';

//DISTRICTS
export const DISTRICTS = 'districts';

//STATES
export const STATES = 'states';

//Donors
export const DONORS = 'donors';

//Donation Request
export const DONATIONS = 'donations';

//blood-inventories
export const BLOOD_INVENTORIES = 'blood-inventories';


