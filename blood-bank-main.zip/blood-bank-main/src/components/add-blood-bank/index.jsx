import React, { useEffect, useState } from "react";
import {
    Form,
    Input,
    Select,
    Radio,
    Button,
    Row,
    Col,
    Card,
    Layout,
    message,
} from "antd";
import axios from "axios";
import {
    API_BASE_URL,
    CITIES,
    DISTRICTS,
    STATES,
    BLOOD_BANK,
} from "../../constants/ApiConst";
import { requestConfig } from "../../constants/Token";

const { Content } = Layout;
const { Option } = Select;
const RadioGroup = Radio.Group;

const AddBloodBank = () => {
    const [form] = Form.useForm();
    const [districts, setDistricts] = useState([]);
    const [cities, setCities] = useState([]);
    const [states, setStates] = useState([]);

    // Function to fetch districts
    const fetchDistricts = () => {
        axios
            .get(`${API_BASE_URL}${DISTRICTS}?populate=state`, { ...requestConfig })
            .then((res) => {
                const transformedDistricts = res.data.data.map((district) => ({
                    key: district.id,
                    name: district.attributes.name,
                    // Assuming the state information is stored under attributes.state
                    state: district.attributes.state ? district.attributes.state : "N/A",
                }));
                setDistricts(transformedDistricts);
            })
            .catch((err) => {
                console.log(err);
            });
    };

    const fetchCities = () => {
        axios
            .get(`${API_BASE_URL}${CITIES}`, { ...requestConfig })
            .then((res) => {
                const transformedCities = res.data.data.map((city) => ({
                    key: city.id,
                    name: city.attributes.name,
                }));
                setCities(transformedCities);
            })
            .catch((err) => {
                console.log(err);
            });
    };

    const fetchStates = () => {
        axios
            .get(`${API_BASE_URL}${STATES}`, { ...requestConfig })
            .then((res) => {
                const transformedStates = res.data.data.map((state) => ({
                    key: state.id,
                    name: state.attributes.name,
                }));
                setStates(transformedStates);
            })
            .catch((err) => {
                console.log(err);
            });
    };

    useEffect(() => {
        fetchDistricts();
        fetchCities();
        fetchStates();
    }, []);

    const onFinish = (values) => {
        console.log(values);
        const formattedValues = {
            data: {
                name: values.name,
                phone_number: values.phone_number ? values.phone_number.toString() : "",
                email: values.email,
                address: values.address,
                state: values.state,
                district: values.district,
                city: values.city,
                blood_bank_type: values.blood_bank_type,
                license_name: values.license_name,
                blood_type: values.blood_type,
            },
        };

        axios
            .post(`${API_BASE_URL}${BLOOD_BANK}?populate=state&populate=district&populate=city`, formattedValues, { ...requestConfig })
            .then((res) => {
                message.success("Bank is added successfully!");
                //reset all the feilds of the form
                form.resetFields();
            })
            .catch((err) => {
                console.log(err);
                message.error(
                    "Add Bank failed! Error: " +
                    (err.response && err.response.data.error
                        ? err.response.data.error.status
                        : "Unknown error")
                );
            });
    };
    return (
        <Content className="content-wrapper">
            <div className="container-fluid">
                <div className="heading-area">
                    <h1 className="page-title">Add Blood Bank</h1>
                </div>

                <Card>
                    <Form form={form} layout="vertical" onFinish={onFinish}>
                        <Row gutter={16}>
                            <Col lg={24} xs={24}>
                                <Form.Item
                                    name="name"
                                    label="Name of the Blood Bank"
                                    rules={[
                                        { required: true, message: "Please input your full name!" },
                                    ]}
                                >
                                    <Input />
                                </Form.Item>
                            </Col>

                            <Col lg={12} xs={24}>
                                <Form.Item
                                    name="phone_number"
                                    label="Phone Number"
                                    rules={[
                                        {
                                            required: true,
                                            message: "Please input your mobile number!",
                                        },
                                        {
                                            pattern: new RegExp(/^[0-9]{10}$/),
                                            message: "Please enter a valid 10-digit mobile number!",
                                        },
                                    ]}
                                >
                                    <Input />
                                </Form.Item>
                            </Col>

                            <Col lg={12} xs={24}>
                                <Form.Item
                                    name="email"
                                    label="Email"
                                    rules={[
                                        { required: true, message: "Please input your email!" },
                                        { type: "email", message: "Please enter a valid email!" },
                                    ]}
                                >
                                    <Input />
                                </Form.Item>
                            </Col>

                            <Col lg={24} xs={24}>
                                <Form.Item
                                    name="address"
                                    label="Address"
                                    rules={[
                                        { required: true, message: 'Please input your address!' }
                                    ]}
                                >
                                    <Input />
                                </Form.Item>
                            </Col>

                            <Col lg={8} xs={24}>
                                <Form.Item
                                    name="state"
                                    label="State"
                                    rules={[
                                        { required: true, message: "Please select a state!" },
                                    ]}
                                >
                                    <Select placeholder="-- State --">
                                        {states.length > 0
                                            ? states.map((state) => (
                                                <Option key={state.key} value={state.key}>
                                                    {state.name}
                                                </Option>
                                            ))
                                            : null}
                                    </Select>
                                </Form.Item>
                            </Col>

                            <Col lg={8} xs={24}>
                                <Form.Item
                                    name="district"
                                    label="District"
                                    rules={[
                                        { required: true, message: "Please select a district!" },
                                    ]}
                                >
                                    <Select placeholder="-- District --">
                                        {districts.length > 0
                                            ? districts.map((district) => (
                                                <Option key={district.key} value={district.key}>
                                                    {district.name}
                                                </Option>
                                            ))
                                            : null}
                                    </Select>
                                </Form.Item>
                            </Col>

                            <Col lg={8} xs={24}>
                                <Form.Item
                                    name="city"
                                    label="City"
                                    rules={[{ required: true, message: "Please select a city!" }]}
                                >
                                    <Select placeholder="-- City --">
                                        {cities.length > 0
                                            ? cities.map((city) => (
                                                <Option key={city.key} value={city.key}>
                                                    {city.name}
                                                </Option>
                                            ))
                                            : null}
                                    </Select>
                                </Form.Item>
                            </Col>

                            <Col span={24}>
                                <Form.Item
                                    name="blood_bank_type"
                                    label="Type of Blood Bank"
                                    rules={[
                                        { required: true, message: "Please select an option!" },
                                    ]}
                                >
                                    <RadioGroup>
                                        <Radio value="Public">Public</Radio>
                                        <Radio value="Private">Private</Radio>
                                        <Radio value="Hospital Based">Hospital Based</Radio>
                                        <Radio value="Independent">Independent</Radio>
                                    </RadioGroup>
                                </Form.Item>
                            </Col>

                            <Col lg={24} xs={24}>
                                <Form.Item
                                    name="license_name"
                                    label="License/Certification Number"
                                    rules={[
                                        { required: true, message: "Please input your License/Certification Number!" },
                                    ]}
                                >
                                    <Input />
                                </Form.Item>
                            </Col>

                            <Col lg={24} xs={24}>
                                <Form.Item
                                    name="blood_type"
                                    label="Blood Types Available"
                                    rules={[{ required: true, message: 'Please input the blood group!' }]}
                                >
                                    <RadioGroup>
                                        <Radio value="A+ (A Positive)">A+</Radio>
                                        <Radio value="A- (A Negative)">A-</Radio>
                                        <Radio value="B+ (B Positive)">B+</Radio>
                                        <Radio value="B- (B Negative)">B-</Radio>
                                        <Radio value="AB+ (AB Positive)">AB+</Radio>
                                        <Radio value="AB- (AB Negative)">AB-</Radio>
                                        <Radio value="O+ (O Positive)">O+</Radio>
                                        <Radio value="O- (O Negative)">O-</Radio>
                                    </RadioGroup>
                                </Form.Item>
                            </Col>

                            <Col span={24}>
                                <Form.Item>
                                    <Button type="primary" danger htmlType="submit">
                                        Submit
                                    </Button>
                                </Form.Item>
                            </Col>
                        </Row>
                    </Form>
                </Card>
            </div>
        </Content>
    );
};

export default AddBloodBank;
