import { Button } from "antd";
import React from "react";
import { useNavigate } from "react-router-dom";

const Logout = () => {
    const navigate = useNavigate();

    const HandleLogout = () => {
        sessionStorage.removeItem("authToken");
        navigate("/auth/login");
    };

    return (
        <div>
            <Button className="btn btn-outline-red" onClick={HandleLogout}>
                Log Out
            </Button>
        </div>
    )
};

export default Logout;