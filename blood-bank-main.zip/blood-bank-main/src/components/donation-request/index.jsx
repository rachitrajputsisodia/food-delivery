import React, { useEffect, useState } from "react";
import {
    Form,
    Input,
    Select,
    Button,
    Row,
    Col,
    Card,
    Layout,
    InputNumber,
    message,
} from "antd";
import axios from "axios";
import { API_BASE_URL, CITIES, DISTRICTS, STATES, DONATIONS } from "../../constants/ApiConst";
import { requestConfig } from "../../constants/Token";

const { Content } = Layout;
const { Option } = Select;
const { TextArea } = Input;

const DonationRequest = () => {
    const [form] = Form.useForm();
    const [districts, setDistricts] = useState([]);
    const [cities, setCities] = useState([]);
    const [states, setStates] = useState([]);

    // Function to fetch districts
    const fetchDistricts = () => {
        axios
            .get(`${API_BASE_URL}${DISTRICTS}?populate=state`, { ...requestConfig })
            .then((res) => {
                const transformedDistricts = res.data.data.map((district) => ({
                    key: district.id,
                    name: district.attributes.name,
                    // Assuming the state information is stored under attributes.state
                    state: district.attributes.state ? district.attributes.state : "N/A",
                }));
                setDistricts(transformedDistricts);
            })
            .catch((err) => {
                console.log(err);
            });
    };

    const fetchCities = () => {
        axios
            .get(`${API_BASE_URL}${CITIES}`, { ...requestConfig })
            .then((res) => {
                const transformedCities = res.data.data.map((city) => ({
                    key: city.id,
                    name: city.attributes.name,
                }));
                setCities(transformedCities);
            })
            .catch((err) => {
                console.log(err);
            });
    };

    const fetchStates = () => {
        axios
            .get(`${API_BASE_URL}${STATES}`, { ...requestConfig })
            .then((res) => {
                const transformedStates = res.data.data.map((state) => ({
                    key: state.id,
                    name: state.attributes.name,
                }));
                setStates(transformedStates);
            })
            .catch((err) => {
                console.log(err);
            });
    };

    useEffect(() => {
        fetchDistricts();
        fetchCities();
        fetchStates();
    }, []);

    const onFinish = (values) => {
        const formattedData = {
            data: {
                name: values.name,
                blood_group: values.blood_group,
                email: values.email,
                contact_number: values.contact_number ? values.contact_number.toString() : "",
                medical_condition_description: values.medical_condition_description,
                // Add state, district, and city based on your API's expectations
                state: values.state,
                district: values.district,
                city: values.city,
            }
        };

        axios.post(`${API_BASE_URL}${DONATIONS}`, formattedData, { ...requestConfig })
            .then(response => {
                message.success("Donation request submitted successfully!");
                form.resetFields();
            })
            .catch(error => {
                console.error("Submission error:", error);
                message.error(`Submission failed, please try again later. ${error.response && error.response.data.error ? error.response.data.error : ''}`);
            });
    };


    const onFinishFailed = (errorInfo) => {
        console.log("Failed:", errorInfo);
        message.error("Please check the form for errors.");
    };

    return (
        <Content className="content-wrapper">
            <div className="container-fluid">
                <div className="heading-area">
                    <h1 className="page-title">Donation Request</h1>
                </div>

                <Card>
                    <Form
                        form={form}
                        layout="vertical"
                        onFinish={onFinish}
                        onFinishFailed={onFinishFailed}
                    >
                        <Row gutter={16}>
                            <Col xs={24}>
                                <Form.Item
                                    name="name"
                                    label="Full Name"
                                    rules={[
                                        { required: true, message: "Please input your full name!" },
                                    ]}
                                >
                                    <Input placeholder="Full Name" />
                                </Form.Item>
                            </Col>

                            <Col lg={12} xs={24}>
                                <Form.Item
                                    name="contact_number"
                                    label="Mobile Number"
                                    rules={[
                                        {
                                            required: true,
                                            message: "Please input your mobile number!",
                                        },
                                        {
                                            type: "number",
                                            message: "Mobile number must be a number!",
                                        },
                                    ]}
                                >
                                    <InputNumber
                                        style={{ width: "100%" }}
                                        placeholder="Mobile Number"
                                    />
                                </Form.Item>
                            </Col>

                            <Col lg={12} xs={24}>
                                <Form.Item
                                    name="email"
                                    label="Email"
                                    rules={[
                                        { required: true, message: "Please input your email!" },
                                        {
                                            type: "email",
                                            message: "The input is not a valid email!",
                                        },
                                    ]}
                                >
                                    <Input placeholder="Email" />
                                </Form.Item>
                            </Col>

                            <Col lg={12} xs={24}>
                                <Form.Item
                                    name="state"
                                    label="State"
                                    rules={[
                                        { required: true, message: "Please select your state!" },
                                    ]}
                                >
                                    <Select placeholder="-- State --">
                                        {states.length > 0
                                            ? states.map((state) => (
                                                <Option key={state.key} value={state.key}>
                                                    {state.name}
                                                </Option>
                                            ))
                                            : null}
                                    </Select>
                                </Form.Item>
                            </Col>

                            <Col lg={12} xs={24}>
                                <Form.Item
                                    name="district"
                                    label="District"
                                    rules={[
                                        { required: true, message: "Please select your district!" },
                                    ]}
                                >
                                    <Select placeholder="-- District --">
                                        {districts.length > 0
                                            ? districts.map((district) => (
                                                <Option key={district.key} value={district.key}>
                                                    {district.name}
                                                </Option>
                                            ))
                                            : null}
                                    </Select>
                                </Form.Item>
                            </Col>

                            <Col lg={12} xs={24}>
                                <Form.Item
                                    name="city"
                                    label="City"
                                    rules={[
                                        { required: true, message: "Please select your city!" },
                                    ]}
                                >
                                    <Select placeholder="-- City --">
                                        {cities.length > 0
                                            ? cities.map((city) => (
                                                <Option key={city.key} value={city.key}>
                                                    {city.name}
                                                </Option>
                                            ))
                                            : null}
                                    </Select>
                                </Form.Item>
                            </Col>

                            <Col lg={12} xs={24}>
                                <Form.Item
                                    name="blood_group"
                                    label="Blood Group"
                                    rules={[
                                        {
                                            required: true,
                                            message: "Please select your blood group!",
                                        },
                                    ]}
                                >
                                    <Select placeholder="Select a Blood Group">
                                        <Option value="A+ (A Positive)">A+</Option>
                                        <Option value="A- (A Negative)">A-</Option>
                                        <Option value="B+ (B Positive)">B+</Option>
                                        <Option value="B- (B Negative)">B-</Option>
                                        <Option value="AB+ (AB Positive)">AB+</Option>
                                        <Option value="AB- (AB Negative)">AB-</Option>
                                        <Option value="O+ (O Positive)">O+</Option>
                                        <Option value="O- (O Negative)">O-</Option>
                                    </Select>
                                </Form.Item>
                            </Col>

                            <Col span={24}>
                                <Form.Item
                                    name="medical_condition_description"
                                    label="Medical Condition Description"
                                    rules={[
                                        {
                                            required: true,
                                            message: "Please describe your medical condition!",
                                        },
                                    ]}
                                >
                                    <TextArea
                                        rows={3}
                                        placeholder="Medical Condition Description"
                                    />
                                </Form.Item>
                            </Col>

                            <Col span={24}>
                                <Form.Item>
                                    <Button
                                        type="primary"
                                        htmlType="submit"
                                        className="btn-red btn"
                                    >
                                        Submit
                                    </Button>
                                </Form.Item>
                            </Col>
                        </Row>
                    </Form>
                </Card>
            </div>
        </Content>
    );
};

export default DonationRequest;
