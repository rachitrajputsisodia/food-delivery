import React from 'react';
import { Card, Form, Button, Typography, Row, Col, Layout } from 'antd';
import { CheckCircleOutlined, CloseCircleOutlined } from '@ant-design/icons';

const { Text } = Typography;
const { Content } = Layout;

const DonationRequestDetails = ({ donationDetails }) => {
    // Assuming donationDetails is an object containing all the required information
    return (
        <Content className="content-wrapper">
            <div className="container-fluid">
                <div className="heading-area">
                    <h1 className="page-title">New Donation Request</h1>
                </div>
                <Card style={{ margin: '20px', padding: '5px' }}>
                    <Form layout="vertical">
                        <Row gutter={[59, 59]}>
                            {/* Full Name */}
                            <Col span={24}>
                                <Text strong>Full Name:</Text>
                                <Text>{donationDetails.data.attributes.name || "N/A"}</Text>
                            </Col>

                            {/* Contact Number */}
                            <Col span={24}>
                                <Text strong>Contact Number:</Text>
                                <Text>{donationDetails.data.attributes.contact_number || "N/A"}</Text>
                            </Col>

                            {/* Email */}
                            <Col span={24}>
                                <Text strong>Email:</Text>
                                <Text>{donationDetails.data.attributes.email || "N/A"}</Text>
                            </Col>

                            {/* Blood Group */}
                            <Col span={24}>
                                <Text strong>Blood Group:</Text>
                                <Text>{donationDetails.data.attributes.blood_group || "N/A"}</Text>
                            </Col>

                            {/* Medical Condition Description */}
                            <Col span={24}>
                                <Text strong>Medical Condition Description:</Text>
                                <Text>{donationDetails.data.attributes.medical_condition_description || "N/A"}</Text>
                            </Col>

                            <Col>
                                <Button type="primary" icon={<CheckCircleOutlined />} style={{ marginRight: '8px' }}>
                                    Accept
                                </Button>
                                <Button danger icon={<CloseCircleOutlined />}>
                                    Discard
                                </Button>
                            </Col>
                        </Row>
                    </Form>
                </Card>
            </div>
        </Content>
    );
};

export default DonationRequestDetails;
