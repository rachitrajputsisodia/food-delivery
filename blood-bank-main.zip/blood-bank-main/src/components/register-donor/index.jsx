import React, { useEffect, useState } from "react";
import { Form, Input, Select, DatePicker, Radio, Checkbox, Button, Row, Col, Card, Layout, message } from "antd";
import axios from "axios";
import { API_BASE_URL, CITIES, DISTRICTS, STATES, DONORS } from "../../constants/ApiConst";
import { requestConfig } from "../../constants/Token";

const { Content } = Layout;
const { Option } = Select;
const RadioGroup = Radio.Group;

const RegisterDonor = () => {
    const [form] = Form.useForm();
    const [districts, setDistricts] = useState([]);
    const [cities, setCities] = useState([]);
    const [states, setStates] = useState([]);

    // Function to fetch districts
    const fetchDistricts = () => {
        axios
            .get(`${API_BASE_URL}${DISTRICTS}?populate=state`, { ...requestConfig })
            .then((res) => {
                const transformedDistricts = res.data.data.map((district) => ({
                    key: district.id,
                    name: district.attributes.name,
                    // Assuming the state information is stored under attributes.state
                    state: district.attributes.state ? district.attributes.state : "N/A",
                }));
                setDistricts(transformedDistricts);
            })
            .catch((err) => {
                console.log(err);
            });
    };

    const fetchCities = () => {
        axios
            .get(`${API_BASE_URL}${CITIES}`, { ...requestConfig })
            .then((res) => {
                const transformedCities = res.data.data.map((city) => ({
                    key: city.id,
                    name: city.attributes.name,
                }));
                setCities(transformedCities);
            })
            .catch((err) => {
                console.log(err);
            });
    };

    const fetchStates = () => {
        axios
            .get(`${API_BASE_URL}${STATES}`, { ...requestConfig })
            .then((res) => {
                const transformedStates = res.data.data.map((state) => ({
                    key: state.id,
                    name: state.attributes.name,
                }));
                setStates(transformedStates);
            })
            .catch((err) => {
                console.log(err);
            });
    };

    useEffect(() => {
        fetchDistricts();
        fetchCities();
        fetchStates();
    }, []);

    const onFinish = (values) => {
        const formattedValues = {
            data: {
                name: values.full_name,
                gender: values.gender,
                date_of_birth: values.dob ? values.dob.format('YYYY-MM-DD') : null,
                blood_group: values.blood_group,
                email: values.email,
                mobile_number: values.mobile,
                last_date_of_donation: values.donation_date ? values.donation_date.format('YYYY-MM-DD') : null,
                preference: values.preference,
                donated_previously: values.donated_previously === '1' ? 'Yes' : 'No',
                district: [values.district],
                state: [values.state],
                city: [values.city],
                medical_condition: values.medical_condition,
                agree_to_contact: values.agree ? 'Yes' : 'No',
            }
        };

        axios.post(`${API_BASE_URL}${DONORS}`, formattedValues, { ...requestConfig })
            .then(res => {
                message.success('Registration successful!');
                //reset all the feilds of the form
                form.resetFields();
            })
            .catch(err => {
                console.log(err);
                message.error('Registration failed! Error: ' + (err.response && err.response.data.error ? err.response.data.error : 'Unknown error'));
            });
    };

    return (
        <Content className="content-wrapper">
            <div className="container-fluid">
                <div className="heading-area">
                    <h1 className="page-title">Register as a Donor</h1>
                </div>

                <Card>
                    <Form form={form} layout="vertical" onFinish={onFinish}>
                        <Row gutter={16}>
                            <h6 className="my-3 w-100">Personal Details</h6>

                            <Col lg={8} xs={24}>
                                <Form.Item
                                    name="full_name"
                                    label="Full Name"
                                    rules={[{ required: true, message: 'Please input your full name!' }]}
                                >
                                    <Input />
                                </Form.Item>
                            </Col>

                            <Col lg={8} xs={24}>
                                <Form.Item
                                    name="gender"
                                    label="Gender"
                                    rules={[{ required: true, message: 'Please select your gender!' }]}
                                >
                                    <Select placeholder="Select Gender">
                                        <Option value="Male">Male</Option>
                                        <Option value="Female">Female</Option>
                                        <Option value="Other">Other</Option>
                                    </Select>
                                </Form.Item>
                            </Col>

                            <Col lg={8} xs={24}>
                                <Form.Item
                                    name="dob"
                                    label="Date of Birth"
                                    rules={[{ required: true, message: 'Please select your date of birth!' }]}
                                >
                                    <DatePicker style={{ width: '100%' }} />
                                </Form.Item>
                            </Col>

                            <Col lg={8} xs={24}>
                                <Form.Item
                                    name="blood_group"
                                    label="Blood Group"
                                    rules={[{ required: true, message: 'Please select your blood group!' }]}
                                >
                                    <Select placeholder="Select a Blood Group">
                                        <Option value="A+ (A Positive)">A+</Option>
                                        <Option value="A- (A Negative)">A-</Option>
                                        <Option value="B+ (B Positive)">B+</Option>
                                        <Option value="B- (B Negative)">B-</Option>
                                        <Option value="AB+ (AB Positive)">AB+</Option>
                                        <Option value="AB- (AB Negative)">AB-</Option>
                                        <Option value="O+ (O Positive)">O+</Option>
                                        <Option value="O- (O Negative)">O-</Option>
                                    </Select>
                                </Form.Item>
                            </Col>

                            <h6 className="my-3 w-100">Contact Details</h6>

                            <Col lg={6} xs={24}>
                                <Form.Item
                                    name="mobile"
                                    label="Mobile Number"
                                    rules={[{ required: true, message: 'Please input your mobile number!' }, { pattern: new RegExp(/^[0-9]{10}$/), message: 'Please enter a valid 10-digit mobile number!' }]}
                                >
                                    <Input />
                                </Form.Item>
                            </Col>

                            <Col lg={6} xs={24}>
                                <Form.Item
                                    name="email"
                                    label="Email"
                                    rules={[{ required: true, message: 'Please input your email!' }, { type: 'email', message: 'Please enter a valid email!' }]}
                                >
                                    <Input />
                                </Form.Item>
                            </Col>

                            <h6 className="my-3 w-100">Location Details</h6>

                            <Col lg={8} xs={24}>
                                <Form.Item
                                    name="state"
                                    label="State"
                                    rules={[{ required: true, message: 'Please select a state!' }]}
                                >
                                    <Select placeholder="-- State --">
                                        {states.length > 0
                                            ? states.map((state) => (
                                                <Option key={state.key} value={state.key}>
                                                    {state.name}
                                                </Option>
                                            ))
                                            : null}
                                    </Select>
                                </Form.Item>
                            </Col>

                            <Col lg={8} xs={24}>
                                <Form.Item
                                    name="district"
                                    label="District"
                                    rules={[{ required: true, message: 'Please select a district!' }]}
                                >
                                    <Select placeholder="-- District --">
                                        {districts.length > 0
                                            ? districts.map((district) => (
                                                <Option key={district.key} value={district.key}>
                                                    {district.name}
                                                </Option>
                                            ))
                                            : null}
                                    </Select>
                                </Form.Item>
                            </Col>

                            <Col lg={8} xs={24}>
                                <Form.Item
                                    name="city"
                                    label="City"
                                    rules={[{ required: true, message: 'Please select a city!' }]}
                                >
                                    <Select placeholder="-- City --">
                                        {cities.length > 0
                                            ? cities.map((city) => (
                                                <Option key={city.key} value={city.key}>
                                                    {city.name}
                                                </Option>
                                            ))
                                            : null}
                                    </Select>
                                </Form.Item>
                            </Col>

                            <h6 className="w-100 my-3">Donor Specific Information</h6>

                            <Col lg={6} xs={24}>
                                <Form.Item
                                    name="donation_date"
                                    label="Latest Date of Donation"
                                    rules={[{ required: true, message: 'Please select the latest date of donation!' }]}
                                >
                                    <DatePicker style={{ width: '100%' }} />
                                </Form.Item>
                            </Col>

                            <Col lg={6} xs={24}>
                                <Form.Item
                                    name="preference"
                                    label="Donation Preference"
                                    rules={[{ required: true, message: 'Please select your donation preference!' }]}
                                >
                                    <Select placeholder="Select Donation Preference">
                                        <Option value="Unit 1">Unit 1</Option>\
                                        <Option value="Unit 2">Unit 2</Option>
                                        <Option value="Unit 3">Unit 3</Option>
                                    </Select>
                                </Form.Item>
                            </Col>

                            <Col span={24}>
                                <Form.Item
                                    name="donated_previously"
                                    label="Have you donated previously?"
                                    rules={[{ required: true, message: 'Please select an option!' }]}
                                >
                                    <RadioGroup>
                                        <Radio value="Yes">Yes</Radio>
                                        <Radio value="No">No</Radio>
                                    </RadioGroup>
                                </Form.Item>
                            </Col>

                            <Col span={24}>
                                <Form.Item
                                    name="health_conditions"
                                    label="In the last six months have you had any of the following?"
                                    rules={[{ required: true, message: 'Please select an option!' }]}
                                >
                                    <Checkbox.Group style={{ width: '100%' }}>
                                        <Row>
                                            <Col span={6}><Checkbox value="Tattooing">Tattooing</Checkbox></Col>
                                            <Col span={6}><Checkbox value="Piercing">Piercing</Checkbox></Col>
                                            <Col span={6}><Checkbox value="DentalExtraction">Dental Extraction</Checkbox></Col>
                                            <Col span={6}><Checkbox value="None">None</Checkbox></Col>
                                        </Row>
                                    </Checkbox.Group>
                                </Form.Item>
                            </Col>

                            <Col span={24}>
                                <Form.Item
                                    name="agree"
                                    valuePropName="checked"
                                    rules={[{ validator: (_, value) => value ? Promise.resolve() : Promise.reject(new Error('You must agree to be contacted!')) }]}
                                >
                                    <Checkbox>I agree to be contacted by blood banks, SBTCs, and NBTC</Checkbox>
                                </Form.Item>
                            </Col>

                            <Col span={24}>
                                <Form.Item>
                                    <Button type="primary" htmlType="submit">Submit</Button>
                                </Form.Item>
                            </Col>
                        </Row>
                    </Form>
                </Card>
            </div>
        </Content>
    );
};

export default RegisterDonor;
