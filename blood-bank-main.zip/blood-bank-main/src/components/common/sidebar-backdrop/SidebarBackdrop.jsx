import React from "react";

export const SidebarBackdrop = () => {
    return (
        <div class="sidebar-backdrop"></div>
    )
};