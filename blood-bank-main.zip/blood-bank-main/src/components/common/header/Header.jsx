import React, { useEffect, useState } from "react";
import userSvg from "../../../assets/images/user.svg";

export const Header = () => {
    const [userName, setUserName] = useState("");
    const [userId, setUserId] = useState("");

    useEffect(() => {
        // Set the username and userid from the session storage
        const userDetails = JSON.parse(sessionStorage.getItem('userDetails'));
        if (userDetails) { // Check if userDetails is not null
            setUserName(userDetails.name);
            setUserId(userDetails.id);
        }
    }, []);

    return (
        <header className="header">
            <div className="header-wrapper">
                <div className="left-area">
                    <button className="btn" type="button" data-open-sidebar>
                        <i className="bi bi-list"></i>
                    </button>
                </div>
                <div className="right-area">
                    <div className="profile-card">
                        <div className="img-area">
                            <img src={userSvg} alt="User Profile" />
                        </div>
                        <div className="user-details-area">
                            <p className="username">{userName}</p>
                            <p className="user-id">User Id: {userId}</p>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    )
};
