import React from "react";

export const Footer = () => {
    return (
        <footer class="footer">
            <div class="footer-wrapper">
                <div class="left-area">
                    <p>2023 Developed and Maintained by Velocity.</p>
                </div>
                <div class="right-area">
                    <p>Technical Support by Velocity.</p>
                </div>
            </div>
        </footer>
    )
};