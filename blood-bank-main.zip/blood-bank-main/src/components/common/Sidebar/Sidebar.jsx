// Sidebar.jsx
import React from "react";
import Logout from "../../logout/index.jsx";
import { Menu } from "antd";
import { Link } from "react-router-dom";

export const Sidebar = () => {
    let defaultSelectedKeys = [];
    //if url has /blood-bank, then set blood-bank as selected
    const url = window.location.pathname;
    if (url.includes('/blood-bank')) {
        defaultSelectedKeys = ['1'];
    } else if (url.includes('/search-donor')) {
        defaultSelectedKeys = ['2'];
    } else if (url.includes('/donation-request')) {
        defaultSelectedKeys = ['3'];
    } else if (url.includes('/donation-request-list')) {
        defaultSelectedKeys = ['4'];
    } else if (url.includes('/donor-list')) {
        defaultSelectedKeys = ['5'];
    } else if (url.includes('/blood-inventory')) {
        defaultSelectedKeys = ['6'];
    } else if (url.includes('/add-blood-bank')) {
        defaultSelectedKeys = ['7'];
    }

    return (
        <div class="sidebar">
            <div class="upper-section">
                <h2 class="logo">LOGO</h2>
                <button class="btn collapse-menu" type="button" data-collapse-menu>
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>

            <div className="middle-section">
                <nav class="sidenav">
                    <Menu mode="inline" defaultSelectedKeys={defaultSelectedKeys}>
                        <Menu.Item key="1" >
                            <Link to="/blood-bank">
                                <div class="icon-area">
                                    <i class="bi bi-shield-fill-plus"></i>
                                </div>
                                <p>Blood Banks</p>
                            </Link>
                        </Menu.Item>
                        <Menu.Item key="2">
                            <Link to="/search-donor">
                                <div class="icon-area">
                                    <i class="bi bi-search"></i>
                                </div>
                                <p>Search Donors</p>
                            </Link>
                        </Menu.Item>
                        <Menu.Item key="3" >
                            <Link to="/donation-request">
                                <div class="icon-area">
                                    <i class="bi bi-chat-left-dots-fill"></i>
                                </div>
                                <p>Donation Request</p>
                            </Link>
                        </Menu.Item>
                        <Menu.Item key="4" >
                            <Link to="/donation-request-list">
                                <div class="icon-area">
                                    <i class="bi bi-person-raised-hand"></i>
                                </div>
                                <p>Donation Request List</p>
                            </Link>
                        </Menu.Item>
                        <Menu.Item key="5" >
                            <Link to="/donor-list">
                                <div class="icon-area">
                                    <i class="bi bi-people-fill"></i>
                                </div>
                                <p>Donor List</p>
                            </Link>
                        </Menu.Item>
                        <Menu.Item key="6" >
                            <Link to="/blood-inventory">
                                <div class="icon-area">
                                    <i class="bi bi-archive-fill"></i>
                                </div>
                                <p>Blood Inventory</p>
                            </Link>
                        </Menu.Item>
                        <Menu.Item key="7" >
                            <Link to="/add-blood-bank">
                                <div class="icon-area">
                                    <i class="bi bi-building-add"></i>
                                </div>
                                <p>Add Blood Bank</p>
                            </Link>
                        </Menu.Item>
                    </Menu>
                </nav>
            </div>

            <div class="bottom-section">
                <Link to="/register-donor" className="btn btn-red">Register as Donor</Link>
                <Logout />
            </div>
        </div>
    );
};
