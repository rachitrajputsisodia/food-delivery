import React, { useState, useEffect } from 'react';
import { Button, Form, Input, Radio, Select, message } from 'antd';
import { StyledRegister } from "./index.styled";
import { API_BASE_URL, REGISTER, CITIES } from "../../constants/ApiConst";
import axios from 'axios';
import { requestConfig } from '../../constants/Token';
import { useNavigate } from 'react-router-dom';

const { Option } = Select;

const Register = () => {
    const [form] = Form.useForm();
    const [cities, setCities] = useState([]);

    const onFinish = (values) => {
        //Submit the form by calling the axios library
        axios.post(`${API_BASE_URL}${REGISTER}`, values)
            .then(res => {
                message.success('Registration successful!');
            })
            .catch(err => {
                console.log(err);
                //show warning message if registration fails: actual
                message.error('Registration failed! Error: ' + err.response.data.error);
            })
    };

    //Fetch the city list from the API
    useEffect(() => {
        axios.get(`${API_BASE_URL}${CITIES}`, { ...requestConfig })
            .then(res => {
                //Show the cities in the cities input fields
                setCities(res.data.data);
            })
            .catch(err => {
                console.log(err);
            })
    }, []);

    const navigate = useNavigate();

    const handleLoginClick = () => {
        navigate('/auth/login');
    };


    return (
        <StyledRegister>
            <div className="auth-wrapper">
                <div className="card auth-card">
                    <div className='card-body'>
                        <div className="auth-header">
                            <h2 className="card-title">Sign up</h2>
                        </div>

                        <Form
                            form={form}
                            layout="vertical"
                            name="register"
                            onFinish={onFinish}
                        >
                            <Form.Item
                                label="Name"
                                name="name"
                                rules={[{ required: true, message: 'Please input your name!' }]}
                            >
                                <Input />
                            </Form.Item>

                            <Form.Item
                                label="Username"
                                name="username"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your username!'
                                    },
                                    {
                                        min: 6,
                                        message: 'Username must be at least 6 characters long!',
                                    },
                                    {
                                        pattern: new RegExp(/^[a-zA-Z0-9]+$/),
                                        message: 'Username should not contain space and special characters!',
                                    },

                                ]}
                            >
                                <Input />
                            </Form.Item>

                            <Form.Item
                                label="Gender"
                                name="gender"
                                rules={[{ required: true, message: 'Please select your gender!' }]}
                            >
                                <Radio.Group>
                                    <Radio value="Male">Male</Radio>
                                    <Radio value="Female">Female</Radio>
                                    <Radio value="Other">Other</Radio>
                                </Radio.Group>
                            </Form.Item>

                            <Form.Item
                                label="Email"
                                name="email"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your email!'
                                    },
                                    {
                                        type: "email",
                                        message: 'Please enter a valid email!'
                                    }
                                ]}
                            >
                                <Input type="email" />
                            </Form.Item>

                            <Form.Item
                                label="Contact Number"
                                name="contact_number"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your contact number!'
                                    },
                                    {
                                        pattern: new RegExp(/^[0-9]{10}$/),
                                        message: 'Please enter a valid 10-digit mobile number!',
                                    },
                                ]}
                            >
                                <Input type="number" />
                            </Form.Item>

                            <Form.Item
                                label="City"
                                name="city"
                                rules={[{ required: true, message: 'Please select your city!' }]}
                            >
                                <Select placeholder="Select a city">
                                    {Array.isArray(cities) && cities.length > 0 ? cities.map(city => (
                                        <Option key={city.id} value={city.id}>{city.attributes.name}</Option>
                                    )) : null}
                                </Select>
                            </Form.Item>

                            <Form.Item
                                label="Address"
                                name="address"
                                rules={[{ required: true, message: 'Please input your address!' }]}
                            >
                                <Input />
                            </Form.Item>

                            <Form.Item
                                label="Password"
                                name="password"
                                rules={[{ required: true, message: 'Please input your password!' }]}
                            >
                                <Input.Password />
                            </Form.Item>

                            <Form.Item
                                label="Role"
                                name="role"
                                rules={[{ required: true, message: 'Please select your role!' }]}
                            >
                                <Radio.Group>
                                    <Radio value="8">User</Radio>
                                    <Radio value="7">Admin</Radio>
                                    <Radio value="6">Super Admin</Radio>
                                </Radio.Group>
                            </Form.Item>

                            <Form.Item>
                                <Button type="primary" danger htmlType="submit" block>
                                    Sign up
                                </Button>
                            </Form.Item>
                        </Form>

                        <div className="auth-bottom-area">
                            <p>Already have an account? <button className="btn btn-link" onClick={handleLoginClick}>Login</button></p>
                        </div>
                    </div>
                </div>
            </div>
        </StyledRegister>
    );
};

export default Register;