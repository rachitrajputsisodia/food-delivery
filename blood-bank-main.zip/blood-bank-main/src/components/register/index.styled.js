import styled from "styled-components";

export const StyledRegister = styled.div`
  .auth-wrapper {
    padding: 20px;
    max-width: var(--max-width);
    margin: auto;
    display: flex;
    align-items: center;
    min-height: 100vh;
  }

  .auth-card {
    max-width: 500px;
    width: 100%;
    padding: 20px 10px;
  }
  .auth-card .auth-header {
    margin-bottom: 25px;
  }
  .auth-card .auth-header .card-title {
    font-size: 24px;
    margin-bottom: 5px;
  }
  .auth-card .auth-header p {
    font-size: 14px;
  }
  .auth-card .form-action-area {
    margin-top: 25px;
  }
  .auth-card .auth-bottom-area {
    text-align: center;
    margin-top: 15px;
    font-size: 14px;
  }
  .auth-card .auth-bottom-area .btn-link {
    padding: 0;
  }

  @media (max-width: 767px) {
    .auth-wrapper {
      justify-content: center;
    }
  }
`;
