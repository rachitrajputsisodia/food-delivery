import React from 'react';
import { Drawer, Form, Button, Col, Row, Input, Select, DatePicker, message } from 'antd';
import axios from 'axios';
import { API_BASE_URL, BLOOD_INVENTORIES } from '../../constants/ApiConst';
import { requestConfig } from '../../constants/Token';

const { Option } = Select;

const AddBloodBagsForm = ({ visible, onClose }) => {
    const [form] = Form.useForm();


    const onFinish = (values) => {
        const formattedValues = {
            data: {
                blood_group: values.blood_group,
                quantity: values.quantity,
                date_of_collection: values.date_of_collection.format('YYYY-MM-DD'),
            }
        };

        //Call axios api to add the blood bags in post request method
        axios.post(`${API_BASE_URL}${BLOOD_INVENTORIES}`, formattedValues, { ...requestConfig })
            .then(res => {
                message.success('Blood bags added successfully!');
            })
            .catch(err => {
                console.log(err);
                message.error('Failed to add blood bags! Error: ' + err.response.data.error);
            })
    };


    return (
        <Drawer
            title="Add Blood Bags"
            width={360}
            onClose={onClose}
            visible={visible}
            bodyStyle={{ paddingBottom: 80 }}
        >
            <Form layout="vertical" hideRequiredMark onFinish={onFinish} form={form}>
                <Row gutter={16}>
                    <Col span={24}>
                        <Form.Item
                            name="blood_group"
                            label="Blood Group"
                            rules={[{ required: true, message: 'Please select the blood group' }]}
                        >
                            <Select placeholder="Select a Blood Group">
                                <Option value="A+ (A Positive)">A+</Option>
                                <Option value="A- (A Negative)">A-</Option>
                                <Option value="B+ (B Positive)">B+</Option>
                                <Option value="B- (B Negative)">B-</Option>
                                <Option value="AB+ (AB Positive)">AB+</Option>
                                <Option value="AB- (AB Negative)">AB-</Option>
                                <Option value="O+ (O Positive)">O+</Option>
                                <Option value="O- (O Negative)">O-</Option>
                            </Select>
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={16}>
                    <Col span={24}>
                        <Form.Item
                            name="quantity"
                            label="Quantity of Blood Bags"
                            rules={[{ required: true, message: 'Please enter the quantity of blood bags' }]}
                        >
                            <Input placeholder="Enter quantity" />
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={16}>
                    <Col span={24}>
                        <Form.Item
                            name="date_of_collection"
                            label="Date of Collection"
                            rules={[{ required: true, message: 'Please choose the collection date' }]}
                        >
                            <DatePicker style={{ width: '100%' }} />
                        </Form.Item>
                    </Col>
                </Row>
                <div
                    style={{
                        textAlign: 'right',
                    }}
                >

                    <Form.Item style={{ textAlign: 'right' }}>
                        <Button onClick={onClose} style={{ marginRight: 8 }}>
                            Cancel
                        </Button>
                        <Button type="primary" htmlType="submit" className="btn btn-red">
                            Add Bag
                        </Button>
                    </Form.Item>
                </div>
            </Form>
        </Drawer>
    );
};

export default AddBloodBagsForm;
