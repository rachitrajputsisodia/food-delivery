import React, { useEffect, useState } from "react";
import { Layout, Table, Select, Avatar } from "antd";
import { BLOOD_BANK_PAGINATION } from "../../config/AppConfig";
import axios from "axios";
import { API_BASE_URL, BLOOD_BANK } from "../../constants/ApiConst";
import { requestConfig } from "../../constants/Token";
import { Link } from "react-router-dom";

import questionSvg from "../../assets/images/question-icon.svg";

const { Content } = Layout;
const { Option } = Select;

const columns = [
    {
        title: "Blood Bank",
        dataIndex: "bloodBank",
        key: "bloodBank",
    },
    {
        title: "Contact Number",
        dataIndex: "contactNumber",
        key: "contactNumber",
    },
    {
        title: "City",
        dataIndex: "city",
        key: "city",
    },
    {
        title: "State",
        dataIndex: "state",
        key: "state",
    },
    {
        title: "Address",
        dataIndex: "address",
        key: "address",
    },
    {
        title: "Action",
        dataIndex: "action",
        key: "action",
    },
];

export const BloodBank = () => {
    const [dataSource, setDataSource] = useState([]);

    useEffect(() => {
        //Action button for the table
        const action = () => {
            return (
                <div>
                    <Link to="/" className="img-icon">
                        <Avatar src={questionSvg} alt="Question Icon" />
                    </Link>
                </div>
            );
        };

        axios
            .get(`${API_BASE_URL}${BLOOD_BANK}`, { ...requestConfig })
            .then((res) => {
                const transformedData = res.data.data.map((item) => ({
                    key: item.id,
                    bloodBank: item.attributes.name ? item.attributes.name : "N/A",
                    contactNumber: item.attributes.phone_number
                        ? item.attributes.phone_number
                        : "N/A",
                    city: item.attributes.city ? item.attributes.city : "N/A",
                    state: item.attributes.state ? item.attributes.state : "N/A",
                    address: item.attributes.address ? item.attributes.address : "N/A",
                    action: action(),
                }));
                setDataSource(transformedData);
            })
            .catch((err) => {
                console.log(err);
            });
    }, []);

    return (
        <Layout className="content-wrapper">
            <Content className="container-fluid">
                <div className="heading-area">
                    <h1 className="page-title">Blood Banks</h1>
                    <div className="action-area">
                        <div className="item">
                            <label htmlFor="state">State</label>
                            <Select defaultValue="" id="state">
                                <Option value="">None Selected</Option>
                            </Select>
                        </div>
                        <div className="item">
                            <label htmlFor="city">City</label>
                            <Select defaultValue="" id="city">
                                <Option value="">None Selected</Option>
                            </Select>
                        </div>
                    </div>
                </div>

                <div className="table-responsive">
                    <Table
                        dataSource={dataSource}
                        columns={columns}
                        pagination={{ pageSize: BLOOD_BANK_PAGINATION.pageSize }}
                    />
                </div>
            </Content>
        </Layout>
    );
};
