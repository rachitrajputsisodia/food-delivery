import React, { useEffect, useState } from "react";
import { Table, Select, Layout, Row, Col } from "antd";

const { Content } = Layout;
const { Option } = Select;

const action = () => {
    return (
        <div>
            <a href="/" className="img-icon">
                <i className="bi bi-pencil-fill"></i>
            </a>
            <a href="/" className="img-icon">
                <i className="bi bi-trash-fill"></i>
            </a>
        </div>
    );
};

const columns = [
    {
        title: "Donor Name",
        dataIndex: "donorName",
        key: "donorName",
    },
    {
        title: "Blood Group",
        dataIndex: "bloodGroup",
        key: "bloodGroup",
    },
    {
        title: "Contact Number",
        dataIndex: "contactNumber",
        key: "contactNumber",
    },
    {
        title: "State",
        dataIndex: "state",
        key: "state",
    },
    {
        title: "City",
        dataIndex: "city",
        key: "city",
    },
    {
        title: "District",
        dataIndex: "district",
        key: "district",
    },
    {
        title: "Action",
        dataIndex: "action",
        render: action,
    },
];

export const DonorsList = (props) => {
    const [dataSource, setDataSource] = useState([]);

    useEffect(() => {
        if (props) {
            const transformedData = props.data.map((item) => ({
                key: item.id,
                donorName: item.attributes.name ? item.attributes.name : "N/A",
                bloodGroup: item.attributes.blood_group ? item.attributes.blood_group : "N/A",
                contactNumber: item.attributes.mobile_number ? item.attributes.mobile_number : "N/A",
                city: item.attributes.city.data.attributes.name ? item.attributes.city.data.attributes.name : "N/A",
                state: item.attributes.state.data.attributes.name ? item.attributes.state.data.attributes.name : "N/A",
                district: item.attributes.district.data.attributes.name ? item.attributes.district.data.attributes.name : "N/A",
            }));

            setDataSource(transformedData);
        }
    }, [props]);

    return (
        <Content className="content-wrapper">
            <div className="container-fluid">
                <div className="heading-area">
                    <h1 className="page-title">Donors</h1>
                    <Row>
                        <Col span={24}>
                            <label htmlFor="city">City</label>
                            <Select defaultValue="" style={{ width: 120 }}>
                                <Option value="">None Selected</Option>
                                {/* Dynamically populate options here */}
                            </Select>
                        </Col>
                    </Row>
                </div>
                <div className="table-responsive">
                    <Table dataSource={dataSource} columns={columns} />
                </div>
                {/* If you're handling pagination yourself, add Pagination component here */}
            </div>
        </Content>
    );
};

export default DonorsList;
