import React, { useEffect, useState } from "react";
import { Row, Col, Layout, Button, message } from "antd";
import { StyledBloodInventoryCard } from "./index.styled";
import bloodDrop from "../../assets/images/blood-drop.png";
import AddBloodBagsForm from "../add-blood-bags-form";
import axios from "axios";
import { API_BASE_URL, BLOOD_INVENTORIES } from "../../constants/ApiConst";
import { requestConfig } from "../../constants/Token";

const { Content } = Layout;

const BloodInventoryCard = ({ type, bags, id }) => (
    <StyledBloodInventoryCard>
        <div className="blood-inventory-card">
            <div className="blood-info">
                <div className="text text-secondary">Bags Available</div>
                <div className="blood-type">{type}</div>
                <div className="blood-bags">{`${bags} Bags`}</div>
            </div>
            <div className="blood-icon">
                <img src={bloodDrop} alt="Blood Drop" />
                <div className="blood-type-overlay">{type.split(' ')[0]}</div>
            </div>
        </div>
    </StyledBloodInventoryCard>
);

const BloodInventory = () => {
    const [visible, setVisible] = useState(false);
    const [bloodInventoryData, setBloodInventoryData] = useState([]);

    const showDrawer = () => {
        setVisible(true);
    };

    const onClose = () => {
        setVisible(false);
    };

    useEffect(() => {
        axios
            .get(`${API_BASE_URL}${BLOOD_INVENTORIES}`, { ...requestConfig })
            .then((res) => {
                const transformedBloodInventory = res.data.data ? res.data.data.map((inventory) => ({
                    type: inventory.attributes?.blood_group || "",
                    bags: inventory.attributes?.quantity || 0,
                    id: inventory.id,
                })) : [];
                setBloodInventoryData(transformedBloodInventory);
            })
            .catch((err) => {
                console.log(err);
                message.error(
                    "Failed to fetch blood inventory data. Error: " +
                    err.response.data.error
                );
            });
    }, []);

    return (
        <Layout className="content-wrapper">
            <Content className="container-fluid">
                <div className="heading-area">
                    <h1 className="page-title">Blood Inventory</h1>
                    <div className="action-area">
                        <div className="item">
                            <Button type="primary" onClick={showDrawer}>
                                Add Blood Bags
                            </Button>
                            <AddBloodBagsForm visible={visible} onClose={onClose} />
                        </div>
                    </div>
                </div>

                <div className="blood-inventory-container">
                    <Row gutter={[16, 16]}>
                        {bloodInventoryData.length > 0 ? bloodInventoryData.map((inventory) => (
                            <Col span={8} key={inventory.type}>
                                <BloodInventoryCard
                                    type={inventory.type}
                                    bags={inventory.bags}
                                    id={inventory.id}
                                />
                            </Col>
                        )) : null}
                    </Row>
                </div>
            </Content>
        </Layout>
    );
};

export default BloodInventory;
