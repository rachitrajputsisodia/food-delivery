import { Card } from "antd";
import styled from "styled-components";

export const StyledBloodInventoryCard = styled(Card)`
  .blood-inventory-card{
    display: flex;
    flex-direction: row;
    position: relative;
  }

  .blood-type {
    color: #ff4d4f; 
    font-size: 24px; 
    margin-bottom: 8px; 
  }
  
  .blood-bags {
    color: #000; 
    font-size: 16px;
  }
  
  .add-blood-bags-button {
    background: #52c41a;
    color: #fff;
    border: none;
    border-radius: 5px;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
  }

  .blood-info{
    width: 70%;
  }

  ..blood-icon{
    width: 30%;
  }

  .blood-icon img {
    width: 100px;
    height: 100px;
    float: right;
  }

  .blood-type-overlay {
    position: absolute;
    top: 50px;
    left: 85%;
    transform: translateX(-50%);
    color: #fff;
    font-size: 1rem;
    z-index: 50;
  }
    
`