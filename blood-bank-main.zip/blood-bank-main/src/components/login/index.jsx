import React from "react";
import { Form, Input, Button, message } from 'antd';

import { StyledRegister } from "../register/index.styled";
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { API_BASE_URL, LOGIN } from "../../constants/ApiConst";

export const Login = () => {

    const navigate = useNavigate();

    const handleRegisterClick = () => {
        navigate('/auth/register');
    };

    const onFinish = (values) => {
        axios.post(`${API_BASE_URL}${LOGIN}`, values)
            .then(res => {
                //Set the token and user details in the session storage
                sessionStorage.setItem('authToken', res.data.jwt);
                sessionStorage.setItem('userDetails', JSON.stringify(res.data.user));
                message.success('Login successful!');
                navigate('/blood-bank');
            })
            .catch(err => {
                console.error(err);
                message.error('Login failed. Please check your User ID and Password.');
            });
    };

    return (
        <StyledRegister>
            <div className="auth-wrapper">
                <div className="card auth-card">
                    <div className="card-body">
                        <div className="auth-header">
                            <h2 className="card-title">Login</h2>
                            <p>Please enter your details to log into your account</p>
                        </div>

                        <Form
                            className="auth-form"
                            layout="vertical"
                            name="register"
                            onFinish={onFinish}
                        >
                            <Form.Item
                                label="User ID"
                                name="identifier"
                                className="form-group"
                                rules={[{ required: true, message: 'Please input your User ID or Email!' }]}
                            >
                                <Input id="user_id" className="form-control" placeholder="User ID" />
                            </Form.Item>

                            <Form.Item
                                label="Password"
                                name="password"
                                className="form-group"
                                rules={[{ required: true, message: 'Please input your Password!' }]}
                            >
                                <Input.Password id="password" placeholder="Password" />
                            </Form.Item>

                            <Form.Item>
                                <Button type="primary" danger htmlType="submit" block>
                                    Login
                                </Button>
                            </Form.Item>
                        </Form>

                        <div className="auth-bottom-area">
                            <p>Don't have an account? <button onClick={handleRegisterClick} className="btn btn-link">Sign up</button></p>
                        </div>
                    </div>
                </div>
            </div>
        </StyledRegister>
    );
}
