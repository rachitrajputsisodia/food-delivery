import React from "react";
import { Form, Select, Button, Row, Col, Card, Layout } from "antd";
import axios from "axios";
import {
    API_BASE_URL,
    CITIES,
    DISTRICTS,
    STATES,
} from "../../constants/ApiConst";
import { requestConfig } from "../../constants/Token";
import { useState, useEffect } from "react";
import DonorsList from "../donors-list";

const { Option } = Select;
const { Content } = Layout;

const SearchDonor = () => {
    const [form] = Form.useForm();
    const [districts, setDistricts] = useState([]);
    const [cities, setCities] = useState([]);
    const [states, setStates] = useState([]);
    const [donorsData, setDonorsData] = useState([]);

    // Function to fetch districts
    const fetchDistricts = () => {
        axios
            .get(`${API_BASE_URL}${DISTRICTS}?populate=state`, { ...requestConfig })
            .then((res) => {
                const transformedDistricts = res.data.data.map((district) => ({
                    key: district.id,
                    name: district.attributes.name,
                    // Assuming the state information is stored under attributes.state
                    state: district.attributes.state ? district.attributes.state : "N/A",
                }));
                setDistricts(transformedDistricts);
            })
            .catch((err) => {
                console.log(err);
            });
    };

    const fetchCities = () => {
        axios
            .get(`${API_BASE_URL}${CITIES}`, { ...requestConfig })
            .then((res) => {
                const transformedCities = res.data.data.map((city) => ({
                    key: city.id,
                    name: city.attributes.name,
                }));
                setCities(transformedCities);
            })
            .catch((err) => {
                console.log(err);
            });
    };

    const fetchStates = () => {
        axios
            .get(`${API_BASE_URL}${STATES}`, { ...requestConfig })
            .then((res) => {
                const transformedStates = res.data.data.map((state) => ({
                    key: state.id,
                    name: state.attributes.name,
                }));
                setStates(transformedStates);
            })
            .catch((err) => {
                console.log(err);
            });
    };

    useEffect(() => {
        fetchDistricts();
        fetchCities();
        fetchStates();
    }, []);

    const onFinish = (values) => {
        //Fetch teh donors list based on the search criteria
        axios.get(`${API_BASE_URL}donors?populate=state&populate=district&populate=city&sort[0]=createdAt:desc`, { ...requestConfig, params: values })
            .then(res => {
                setDonorsData(res.data.data);
            })
            .catch(err => {
                console.log(err);
            });
    };

    return (
        <Content className="content-wrapper">
            <div className="container-fluid">
                <div className="heading-area">
                    <h1 className="page-title">Search Donors</h1>
                </div>

                <Card>
                    <Form form={form} layout="vertical" name="search-donor" onFinish={onFinish}>
                        <h6 className="my-3">Location Details</h6>
                        <Row gutter={16}>
                            <Col lg={8} xs={24}>
                                <Form.Item
                                    label="State"
                                    name="state"
                                    rules={[
                                        { required: true, message: "Please select a state!" },
                                    ]}
                                >
                                    <Select placeholder="-- State --">
                                        {states.length > 0
                                            ? states.map((state) => (
                                                <Option key={state.key} value={state.name}>
                                                    {state.name}
                                                </Option>
                                            ))
                                            : null}
                                    </Select>
                                </Form.Item>
                            </Col>

                            <Col lg={8} xs={24}>
                                <Form.Item
                                    label="District"
                                    name="district"
                                    rules={[
                                        { required: true, message: "Please select a district!" },
                                    ]}
                                >
                                    <Select placeholder="-- District --">
                                        {districts.length > 0
                                            ? districts.map((district) => (
                                                <Option key={district.key} value={district.name}>
                                                    {district.name}
                                                </Option>
                                            ))
                                            : null}
                                    </Select>
                                </Form.Item>
                            </Col>

                            <Col lg={8} xs={24}>
                                <Form.Item
                                    label="City"
                                    name="city"
                                    rules={[{ required: true, message: "Please select a city!" }]}
                                >
                                    <Select placeholder="-- City --">
                                        {cities.length > 0
                                            ? cities.map((city) => (
                                                <Option key={city.key} value={city.name}>
                                                    {city.name}
                                                </Option>
                                            ))
                                            : null}
                                    </Select>
                                </Form.Item>
                            </Col>
                        </Row>

                        <h6 className="my-3">Blood Group Type</h6>
                        <Row gutter={16}>
                            <Col lg={8} xs={24}>
                                <Form.Item
                                    label="Blood Group"
                                    name="blood_group"
                                    rules={[
                                        { required: true, message: "Please select a blood group!" },
                                    ]}
                                >
                                    <Select placeholder="Select a Blood Group">
                                        <Option value="A+ (A Positive)">A+</Option>
                                        <Option value="A- (A Negative)">A-</Option>
                                        <Option value="B+ (B Positive)">B+</Option>
                                        <Option value="B- (B Negative)">B-</Option>
                                        <Option value="AB+ (AB Positive)">AB+</Option>
                                        <Option value="AB- (AB Negative)">AB-</Option>
                                        <Option value="O+ (O Positive)">O+</Option>
                                        <Option value="O- (O Negative)">O-</Option>
                                    </Select>
                                </Form.Item>
                            </Col>
                        </Row>

                        <Form.Item>
                            <Button type="primary" htmlType="submit" className="btn btn-red">
                                Search
                            </Button>
                        </Form.Item>
                    </Form>

                    {donorsData.length > 0 && <DonorsList data={donorsData} />}
                </Card>
            </div>
        </Content>
    );
};

export default SearchDonor;
