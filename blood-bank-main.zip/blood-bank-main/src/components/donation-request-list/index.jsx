import React, { useEffect, useState } from "react";
import axios from "axios";
import { Table, Layout, message } from "antd";
import { API_BASE_URL, DONATIONS } from "../../constants/ApiConst";
import { requestConfig } from "../../constants/Token";
import { Link } from "react-router-dom";

const { Content } = Layout;

const columns = [
    {
        title: "Name",
        dataIndex: "name",
        key: "name",
    },
    {
        title: "Contact Number",
        dataIndex: "contactNumber",
        key: "contactNumber",
    },
    {
        title: "Email",
        dataIndex: "email",
        key: "email",
    },
    {
        title: "State",
        dataIndex: "state",
        key: "state",
    },
    {
        title: "City",
        dataIndex: "city",
        key: "city",
    },
    {
        title: "District",
        dataIndex: "district",
        key: "district",
    },
    {
        title: "Blood Group",
        dataIndex: "bloodGroup",
        key: "bloodGroup",
    },
    {
        title: "Action",
        key: "action",
        dataIndex: "action",
    },
];

export const DonationRequestList = () => {
    const [dataSource, setDataSource] = useState([]);

    const action = (id) => {
        return (
            <div>
                <Link to={`/donation-request-details/${id}`} className="img-icon">
                    <i className="bi bi-eye-fill"></i>
                </Link>
                <Link to={`/`} className="img-icon">
                    <i className="bi bi-pencil-fill"></i>
                </Link>
                <Link to={`/`} className="img-icon">
                    <i className="bi bi-trash-fill"></i>
                </Link>
            </div>
        );
    };

    useEffect(() => {
        axios.get(`${API_BASE_URL}${DONATIONS}?sort[0]=createdAt:desc`, { ...requestConfig })
            .then(response => {
                const transformedData = response.data.data.map(item => ({
                    key: item.id,
                    name: item.attributes.name ? item.attributes.name : "N/A",
                    contactNumber: item.attributes.contact_number ? item.attributes.contact_number : "N/A",
                    email: item.attributes.email ? item.attributes.email : "N/A",
                    state: item.attributes.state ? item.attributes.state : "N/A",
                    city: item.attributes.city ? item.attributes.city : "N/A",
                    district: item.attributes.district ? item.attributes.district : "N/A",
                    bloodGroup: item.attributes.blood_group ? item.attributes.blood_group : "N/A",
                    action: item.id ? action(item.id) : "",
                }));
                setDataSource(transformedData);
            })
            .catch(error => {
                console.error("Fetch error:", error);
                message.error("Failed to fetch donation requests.");
            });
    }, []);

    return (
        <Content className="content-wrapper">
            <div className="container-fluid">
                <div className="heading-area">
                    <h1 className="page-title">Donation Requests</h1>
                </div>
                <div className="table-responsive">
                    <Table dataSource={dataSource} columns={columns} />
                </div>
            </div>
        </Content>
    );
};

export default DonationRequestList;
