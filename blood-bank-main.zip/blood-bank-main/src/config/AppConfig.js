//Config variables/Values for the pagination on the blood bank page listing
export const BLOOD_BANK_PAGINATION = {
    pageSize: 5
};