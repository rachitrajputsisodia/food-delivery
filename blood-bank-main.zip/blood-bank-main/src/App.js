import React from 'react';
import { RouterProvider } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css';
import '../src/assets/css/main.css';

// Import all routes from views
import { router } from './views';

const App = () => {
    return (
        <RouterProvider router={router} />
    );
};

export default App;
