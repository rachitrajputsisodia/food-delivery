import React from 'react';
import { Outlet } from 'react-router-dom';
import { StyledAppLayout } from './AppLayout.styled';

import { Sidebar } from '../components/common/Sidebar/index';
import { SidebarBackdrop } from '../components/common/sidebar-backdrop/SidebarBackdrop';
import { Header } from '../components/common/header/index';
import { Footer } from '../components/common/footer/index';

const AppLayout = () => {
    return (
        <div>
            <StyledAppLayout>
                <div className='page-wrapper'>
                    <Sidebar />
                    <SidebarBackdrop />
                    <main class="main-wrapper">
                        <Header />
                        <Outlet />
                        <Footer />
                    </main>
                </div>
            </StyledAppLayout>
        </div>
    );
};

export default AppLayout;
