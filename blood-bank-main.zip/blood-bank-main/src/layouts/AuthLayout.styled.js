import styled from 'styled-components';
import backgroundImage from '../assets/images/auth-bg.png';

export const StyledAuthLayout = styled.div`
    .background {
        background-color: #000;
        background-image: url(${backgroundImage});
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-repeat: no-repeat;
    }
`;
