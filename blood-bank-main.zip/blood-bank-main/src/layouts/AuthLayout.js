import React from 'react';
import { Outlet } from 'react-router-dom';
import { StyledAuthLayout } from './AuthLayout.styled';

const AuthLayout = () => {
    return (
        <div>
            <StyledAuthLayout>
                <div className='background'>
                    <Outlet />
                </div>
            </StyledAuthLayout>
        </div>
    );
};

export default AuthLayout;
