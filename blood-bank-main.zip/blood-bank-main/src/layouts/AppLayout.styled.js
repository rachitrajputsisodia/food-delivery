import styled from "styled-components";

export const StyledAppLayout = styled.div``;