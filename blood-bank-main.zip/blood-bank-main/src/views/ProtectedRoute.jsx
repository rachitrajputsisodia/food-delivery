// src/components/common/ProtectedRoute.jsx
import { Navigate, Outlet } from 'react-router-dom';

const ProtectedRoute = () => {
  const authToken = sessionStorage.getItem('authToken');
  return authToken ? <Outlet /> : <Navigate to="/auth/login" replace />;
};

export default ProtectedRoute;
