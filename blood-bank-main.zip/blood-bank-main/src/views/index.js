import React, { lazy, Suspense } from 'react';
import { createBrowserRouter, Navigate } from 'react-router-dom';

import AuthLayout from '../layouts/AuthLayout';
import AppLayout from '../layouts/AppLayout';
import { CustomLoader } from '../components/common/loader/index';
import ProtectedRoute from './ProtectedRoute';
import PublicOnlyRoute from './PublicOnlyRoute';

//Auth Views
const RegisterView = lazy(() => import('./auth-views/register-view'));
const LoginView = lazy(() => import('./auth-views/login-view'));

//App Views
const BloodBankView = lazy(() => import('./app-views/blood-bank-view'));
const SearchDonorView = lazy(() => import('./app-views/search-donor-view'));
const DonationRequestView = lazy(() => import('./app-views/donation-request-view'));
const RegisterDonorView = lazy(() => import('./app-views/register-donor-view'));
const DonationRequestListView = lazy(() => import('./app-views/donation-request-list-view'));
const DonorListView = lazy(() => import('./app-views/donor-list-view'));
const DonationRequestDetailsView = lazy(() => import('./app-views/donation-request-details-view'));
const BloodInventoryView = lazy(() => import('./app-views/blood-inventory-view'));
const AddBloodBankView = lazy(() => import('./app-views/add-blood-bank-view'));

export const router = createBrowserRouter([
    {
        path: '/',
        element: <ProtectedRoute />,
        children: [
            {
                element: <AppLayout />,
                children: [
                    {
                        index: true,
                        element: (
                            <Suspense fallback={<CustomLoader />}>
                                <BloodBankView />
                            </Suspense>
                        )
                    },
                    {
                        path: 'blood-bank',
                        element: (
                            <Suspense fallback={<CustomLoader />}>
                                <BloodBankView />
                            </Suspense>
                        )
                    },
                    {
                        path: 'search-donor',
                        element: (
                            <Suspense fallback={<CustomLoader />}>
                                <SearchDonorView />
                            </Suspense>
                        )
                    },
                    {
                        path: 'donation-request',
                        element: (
                            <Suspense fallback={<CustomLoader />}>
                                <DonationRequestView />
                            </Suspense>
                        )
                    },
                    {
                        path: 'register-donor',
                        element: (
                            <Suspense fallback={<CustomLoader />}>
                                <RegisterDonorView />
                            </Suspense>
                        )
                    },
                    {
                        path: 'donation-request-list',
                        element: (
                            <Suspense fallback={<CustomLoader />}>
                                <DonationRequestListView />
                            </Suspense>
                        )
                    },
                    {
                        path: 'donation-request-details/:id',
                        element: (
                            <Suspense fallback={<CustomLoader />}>
                                <DonationRequestDetailsView />
                            </Suspense>
                        )
                    },
                    {
                        path: 'donor-list',
                        element: (
                            <Suspense fallback={<CustomLoader />}>
                                <DonorListView />
                            </Suspense>
                        )
                    },
                    {
                        path: 'blood-inventory',
                        element: (
                            <Suspense fallback={<CustomLoader />}>
                                <BloodInventoryView />
                            </Suspense>
                        )
                    },
                    {
                        path: 'add-blood-bank',
                        element: (
                            <Suspense fallback={<CustomLoader />}>
                                <AddBloodBankView />
                            </Suspense>
                        )
                    }
                ]
            }
        ]
    },
    {
        path: '/auth',
        element: <PublicOnlyRoute />, // wrap auth routes here
        children: [
            {
                element: <AuthLayout />,
                children: [
                    {
                        index: true,
                        element: (
                            <Suspense fallback={<CustomLoader />}>
                                <RegisterView />
                            </Suspense>
                        )
                    },
                    {
                        path: 'register',
                        element: (
                            <Suspense fallback={<CustomLoader />}>
                                <RegisterView />
                            </Suspense>
                        )
                    },
                    {
                        path: 'login',
                        element: (
                            <Suspense fallback={<CustomLoader />}>
                                <LoginView />
                            </Suspense>
                        )
                    }
                ]
            }
        ]
    },
    {
        path: '*',
        element: <Navigate to="/" />,
    }
]);