import React from "react";
import AddBloodBank from "../../../components/add-blood-bank/index.jsx";

const AddBloodBankView = () => {
    return (
        <div>
            <AddBloodBank />
        </div>
    );
}

export default AddBloodBankView;