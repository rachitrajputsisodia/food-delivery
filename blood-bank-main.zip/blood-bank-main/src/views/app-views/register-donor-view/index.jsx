import React from "react";
import RegisterDonor from "../../../components/register-donor/index.jsx";

const RegisterDonorView = () => {
    return (
        <div>
            <RegisterDonor />
        </div>
    )
};

export default RegisterDonorView;