import React from "react";
import BloodInventory from "../../../components/blood-inventory/index.jsx";

const BloodInventoryView = () => {
    return (
        <div>
            <BloodInventory />
        </div>
    );
}

export default BloodInventoryView;