import React from "react";
import DonationRequest from "../../../components/donation-request/index.jsx";

const DonationRequestView = () => {
    return (
        <div>
            <DonationRequest />
        </div>
    )
};

export default DonationRequestView;