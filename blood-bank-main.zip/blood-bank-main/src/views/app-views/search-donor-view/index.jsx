import React from "react";
import SearchDonor from "../../../components/search-donor/index.jsx";

const SearchDonorView = () => {
    return (
        <div>
            <SearchDonor />
        </div>
    );
}

export default SearchDonorView;