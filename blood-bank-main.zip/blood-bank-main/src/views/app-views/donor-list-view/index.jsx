import React, { useEffect, useState } from "react";
import DonorsList from "../../../components/donors-list/index.jsx";
import axios from "axios";
import { API_BASE_URL, DONORS } from "../../../constants/ApiConst";
import { requestConfig } from "../../../constants/Token";

const DonorListView = () => {
    const [donorsData, setDonorsData] = useState([]);

    // Function to fetch donors
    const fetchDonors = () => {
        axios.get(`${API_BASE_URL}${DONORS}?populate=state&populate=district&populate=city&sort[0]=createdAt:desc`, { ...requestConfig })
            .then((res) => {
                setDonorsData(res.data.data);
            })
            .catch((err) => {
                console.error(err);
            });
    };

    useEffect(() => {
        fetchDonors();
    }, []);

    return (
        <div>
            <DonorsList data={donorsData} />
        </div>
    )
};

export default DonorListView;