import React from "react";
import DonationRequestList from "../../../components/donation-request-list/index.jsx";

const DonationRequestListView = () => {
    return (
        <div>
            <DonationRequestList />
        </div>
    )
};

export default DonationRequestListView;