import React from "react";
import { BloodBank } from "../../../components/blood-bank/index.jsx";

const BloodBankView = () => {
    return (
        <div>
            <BloodBank />
        </div>
    );
}

export default BloodBankView;