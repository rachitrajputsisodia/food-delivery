import React, { Suspense, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { CustomLoader } from "../../../components/common/loader/index"; // Update the path to your CustomLoader component
import { API_BASE_URL, DONATIONS } from "../../../constants/ApiConst";
import { requestConfig } from "../../../constants/Token";

// Lazy load the DonationRequestDetails component
const DonationRequestDetails = React.lazy(() => import("../../../components/donation-request-details/index.jsx"));

const DonationRequestDetailsView = () => {
    const { id } = useParams();
    const [donationDetails, setDonationDetails] = useState(null);

    useEffect(() => {
        const fetchDonationDetails = async () => {
            try {
                const response = await axios.get(`${API_BASE_URL}${DONATIONS}/${id}`, { ...requestConfig });
                setDonationDetails(response.data);
            } catch (error) {
                console.error("Error fetching donation request details:", error);
            }
        };

        fetchDonationDetails();
    }, [id]);

    return (
        <div>
            <Suspense fallback={<CustomLoader />}>
                {donationDetails ? (
                    <DonationRequestDetails donationDetails={donationDetails} />
                ) : (
                    <CustomLoader />
                )}
            </Suspense>
        </div>
    );
};

export default DonationRequestDetailsView;
