// src/components/common/PublicOnlyRoute.jsx
import { Navigate, Outlet } from 'react-router-dom';

const PublicOnlyRoute = () => {
    const authToken = sessionStorage.getItem('authToken');
    return authToken ? <Navigate to="/" replace /> : <Outlet />;
};

export default PublicOnlyRoute;
