import React from "react";

import Register from "../../../components/register";

const RegisterView = () => {
    return (
        <div>
            <Register />
        </div>
    );
}

export default RegisterView;