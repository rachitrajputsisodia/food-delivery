import React from "react";
import { Login } from "../../../components/login";

const LoginView = () => {
    return (
        <div>
            <Login />
        </div>
    );
}

export default LoginView;